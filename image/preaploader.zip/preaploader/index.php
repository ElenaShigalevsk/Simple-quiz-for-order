<script src="http://code.jquery.com/jquery-latest.js"></script>
<script>
$(function() {
		$('#submit').click(function() {
		$('#container').append('<img src="jquery-preloader.gif" alt="��������..." id="loading" />');
				
			var name = $('#name').val();
			var email = $('#email').val();
			var comments = $('#comments').val();
				
			$.ajax({
				url: 'ajax.php',
				type: 'POST',
				data: 'name=' + name + '&email=' + email + '&comments=' + comments,

				success: function(result) {
				$('#response').remove();
				$('#container').append('<p id="response">' + result + '</p>');
				$('#loading').fadeOut(500, function() {
						$(this).remove();
					});	
				}
			});	
			return false;
			});
		});
</script>
<style>
label {
display: block;
}
</style>
<form action="" method="post">
	<div id="container">
        <label for="name">���</label>
		<input type="text" name="name" id="name" />
		
		<label for="email">�����</label>
		<input type="text" name="email" id="email" />
		
		<label for="comments">�����������</label>
		<textarea rows="5" cols="30" name="comments" id="comments"></textarea>
		<br />
		<input type="submit" name="submit" id="submit" value="���������" />
    
	</div>
</form>